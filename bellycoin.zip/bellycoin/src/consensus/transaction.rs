use std::{collections::BTreeSet, error::Error as StdError, fmt};

use common::ChainContext;
use crypto::{Address, PublicKey, TransactionHash};

use crate::ledger::nakama::{NakamaError, RegisterNakama, nakama_name_burn};
use crate::transaction::{Input, IntentError, Output, Pearl, SpendIntent, Transaction, UtxoId};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidatedTransaction {
    pub intent: SpendIntent,
    pub txid: TransactionHash,
    pub registration: Option<RegisterNakama>,
    pub chain: ChainContext,
    pub revealed_key: Option<PublicKey>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BellycoinInputState {
    pub amount: Pearl,
    pub owner: Address,
}

pub trait TransactionStateView {
    fn pearl(&self, id: UtxoId) -> Option<BellycoinInputState>;
    fn public_key(&self, _address: Address) -> Option<PublicKey> {
        None
    }
    fn validate_registration(
        &self,
        _registration: &RegisterNakama,
        _chain: ChainContext,
    ) -> Result<(), NakamaError> {
        Err(NakamaError::InvalidSignature)
    }
}

pub fn validate_transaction(
    transaction: Transaction,
    chain: ChainContext,
    _current_height: u64,
    state: &impl TransactionStateView,
) -> Result<ValidatedTransaction, TransactionConsensusError> {
    transaction
        .intent
        .validate_structure()
        .map_err(TransactionConsensusError::Intent)?;
    let revealed_key = transaction.authorization.public_key.as_ref();
    let stored_key = state.public_key(transaction.intent.sender);
    let public_key = revealed_key
        .or(stored_key.as_ref())
        .or_else(|| {
            transaction
                .registration
                .as_ref()
                .map(|registration| &registration.public_key)
        })
        .ok_or(TransactionConsensusError::UnknownPublicKey)?;
    if stored_key
        .as_ref()
        .is_some_and(|stored| stored != public_key)
    {
        return Err(TransactionConsensusError::InvalidAuthorization);
    }
    if !transaction
        .verify_authorization_with_key(chain, public_key)
        .map_err(|_| TransactionConsensusError::Encoding)?
    {
        return Err(TransactionConsensusError::InvalidAuthorization);
    }

    let intent = &transaction.intent;
    let burn = transaction
        .registration
        .as_ref()
        .map_or(Pearl::ZERO, |registration| nakama_name_burn(&registration.name));
    validate_bellycoin_inputs(&intent.inputs, &intent.outputs, intent.sender, burn, state)?;
    if let Some(registration) = &transaction.registration {
        if &registration.public_key != public_key {
            return Err(TransactionConsensusError::InvalidRegistration(
                NakamaError::WrongOwner,
            ));
        }
        state
            .validate_registration(registration, chain)
            .map_err(TransactionConsensusError::InvalidRegistration)?;
    }

    let key_to_register = stored_key.is_none().then(|| public_key.clone());

    let txid = transaction
        .transaction_id()
        .map_err(|_| TransactionConsensusError::Encoding)?;
    Ok(ValidatedTransaction {
        intent: transaction.intent,
        txid,
        registration: transaction.registration,
        chain,
        revealed_key: key_to_register,
    })
}

fn validate_bellycoin_inputs(
    inputs: &[Input],
    outputs: &[Output],
    sender: Address,
    burn: Pearl,
    state: &impl TransactionStateView,
) -> Result<(), TransactionConsensusError> {
    let mut unique = BTreeSet::new();
    let mut input_total = Pearl::ZERO;
    for input in inputs {
        let id = input.utxo;
        if !unique.insert(id) {
            return Err(TransactionConsensusError::Intent(
                IntentError::DuplicateInput,
            ));
        }
        let previous = state
            .pearl(id)
            .ok_or(TransactionConsensusError::UtxoNotFound)?;
        if previous.owner != sender {
            return Err(TransactionConsensusError::RecipientMismatch);
        }
        input_total = input_total
            .checked_add(previous.amount)
            .ok_or(TransactionConsensusError::PearlOverflow)?;
    }
    let output_total = outputs.iter().try_fold(Pearl::ZERO, |sum, output| {
        sum.checked_add(output.amount)
            .ok_or(TransactionConsensusError::PearlOverflow)
    })?;
    if input_total != output_total.checked_add(burn).ok_or(TransactionConsensusError::PearlOverflow)? {
        return Err(TransactionConsensusError::ValueMismatch);
    }
    Ok(())
}

#[derive(Debug)]
pub enum TransactionConsensusError {
    Encoding,
    Intent(IntentError),
    InvalidAuthorization,
    UnknownPublicKey,
    UtxoNotFound,
    RecipientMismatch,
    PearlOverflow,
    ValueMismatch,
    InvalidRegistration(NakamaError),
}

impl fmt::Display for TransactionConsensusError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Encoding => formatter.write_str("transaction encoding failed"),
            Self::Intent(error) => write!(formatter, "invalid transaction intent: {error}"),
            Self::InvalidAuthorization => {
                formatter.write_str("transaction authorization is invalid")
            }
            Self::UnknownPublicKey => formatter
                .write_str("sender public key is not registered; reveal it in this transaction"),
            Self::UtxoNotFound => formatter.write_str("transaction input UTXO was not found"),
            Self::RecipientMismatch => {
                formatter.write_str("transaction input is not committed to this signer")
            }
            Self::PearlOverflow => formatter.write_str("transaction amount overflow"),
            Self::ValueMismatch => {
                formatter.write_str("transaction input and output values differ")
            }
            Self::InvalidRegistration(error) => {
                write!(formatter, "invalid name registration: {error:?}")
            }
        }
    }
}

impl StdError for TransactionConsensusError {
    fn source(&self) -> Option<&(dyn StdError + 'static)> {
        match self {
            Self::Intent(error) => Some(error),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crypto::TransactionHash;

    struct OneInput {
        outpoint: UtxoId,
        amount: Pearl,
        owner: Address,
    }

    impl TransactionStateView for OneInput {
        fn pearl(&self, id: UtxoId) -> Option<BellycoinInputState> {
            (id == self.outpoint).then_some(BellycoinInputState {
                amount: self.amount,
                owner: self.owner,
            })
        }
    }

    #[test]
    fn spend_requires_exact_value_conservation() {
        let sender = Address([7; crypto::ADDRESS_SIZE]);
        let outpoint = UtxoId::transaction(TransactionHash([9; crypto::HASH_SIZE]), 0);
        let state = OneInput {
            outpoint,
            amount: Pearl::from_pearl(100),
            owner: sender,
        };
        let inputs = [Input::new(outpoint)];
        let outputs = [
            Output::new(sender, Pearl::from_pearl(90)),
            Output::block_miner(Pearl::from_pearl(10)),
        ];
        assert!(validate_bellycoin_inputs(&inputs, &outputs, sender, Pearl::ZERO, &state).is_ok());

        let underfunded = [Output::new(sender, Pearl::from_pearl(99))];
        assert!(matches!(
            validate_bellycoin_inputs(&inputs, &underfunded, sender, Pearl::ZERO, &state),
            Err(TransactionConsensusError::ValueMismatch)
        ));
        let overfunded = [Output::new(sender, Pearl::from_pearl(101))];
        assert!(matches!(
            validate_bellycoin_inputs(&inputs, &overfunded, sender, Pearl::ZERO, &state),
            Err(TransactionConsensusError::ValueMismatch)
        ));
    }
}
